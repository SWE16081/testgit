<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <title>文章</title>
    </head>
    <body>

    <div class="container">
    @include('common.top')
    <div>
        <ol class="breadcrumb">
            <li><a href="{{url('/articleadd')}}">文章添加</a></li>
            <li><a href="#">文章</a></li>
            <li><a href="#">显示</a></li>
        </ol>
      <div>
           @foreach($article as $articles)
              <div class="list-group">
                  <a href="{{url('/articlecontent',['articleid'=>$articles->articleid])}}" class="list-group-item default">
                  {{--{!! $articles->content !!}<!--laravel自带转义-->--}}
                      {{str_limit($articles->content, 120,'...')}}

                  </a>
              </div>
          @endforeach
               <div class="paging">
                   <hr />
                   <span class="pageSpan">{{$article->links()}}</span>
               </div>

      </div>
    </div>

    </div>
    </body>
</html>
