<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <!--移动设备友好样式-->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!--引入后端css样式-->
        <link href="../../../css/admin/login/adminlogin.css" rel="stylesheet">
        <title>SWE16081login--div</title>


    <body>
         <div class="content">
             <div class="pic-img">
                 <img src="../../../pic/hou.png">
             </div>
             <form method="post" action="">
                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" /><!--419bug-->

                 <div class="middle">

                     <div class="middle-padding">
                         <input class="form-control" type="text" placeholder="账号" id="SWEusername" name="SWEusername">
                     </div>
                     <div class="middle-padding">
                      <input  class="form-control"type="password" placeholder="密码" id="SWEpassword" name="SWEpassword">
                     </div>
                     <div class="middle-padding">
                         <input class="btn btn-default"type="submit" value="登陆">
                     </div>

                 </div>
             </form>


         </div>
    </body>
</html>
