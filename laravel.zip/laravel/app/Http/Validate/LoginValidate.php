<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/1
 * Time: 14:43
 */
namespace  App\Http\Validate;
use App\Rules\SensitiveWordRule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class LoginValidate {
    public function check(array $data)
    {
//        dump($data);
                   $res=Validator::make($data, [
               'SWEusername'=> 'required',
//               'SWEpassword' => 'required',
                       'SWEpassword'=>[
                           'required',
//                           function($attibute,$value,$fail){
//                               if(strpos($value,'123')!==false)
//                               {
//                                   return $fail('内容包含敏感词');
//                               }
//                           },
//                           new SensitiveWordRule(),
//                           'regex:/^{[a-zA-Z0-9]}$/'//laravel中用regex 正则表达式匹配验证字段
                           //使用 regex 模式时，规则必须放在数组中，而不能使用管道分隔符
                       ],
               'SWEcode' => 'required|captcha',
           ],[
                       'SWEusername.required'=>trans('账号不能为空'),
                       'SWEpassword.required'=>trans('密码不能为空'),
                       'SWEpassword.regex'=>trans('格式错误'),
                       'SWEcode.required' => trans('验证码不能为空'),
                       'SWEcode.captcha' => trans('验证码错误'),
           ])->validate();

                   return $res;
    }

}