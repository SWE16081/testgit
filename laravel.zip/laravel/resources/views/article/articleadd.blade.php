<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!--添加百度文本编辑器-->
        <script type="text/javascript" charset="utf-8" src="../../../utf8-php/ueditor.config.js"></script>

        <script type="text/javascript" charset="utf-8" src="../../../utf8-php/ueditor.all.min.js"> </script>
        <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
        <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
        <script type="text/javascript" charset="utf-8" src="../../../utf8-php/lang/zh-cn/zh-cn.js"></script>

        <!--引入后端自定义js-->
        <script type="text/javascript" charset="utf-8" src="../../../js/admin/articleAdd.js"></script>
        <!--引入后端css样式-->
        <link href="../../../css/admin/articleAdd.css" rel="stylesheet">
        <title>文章</title>
    </head>
    <body>

    <div class="container">
    @include('common.top')
        <div>
            <ol class="title breadcrumb">
                <li><a href="{{url('/articleshow')}}">后退</a></li>
                <li><a href="#">文章</a></li>
                <li><a href="#">添加</a></li>
            </ol>

                <form method="post" action="/articleadd" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}" /><!--419bug-->
                    <input type="hidden" id="editor"name="editor" value="" />
                    <div class="middle">
                        <div class="middle-padding">
                            <input class="form-control" type="text" style="width: 60%;height: 10%"  placeholder="标题" id="title" name="title">
                            {{--@if($errors->has('SWEusername'))--}}
                            {{--<p class="text-danger text-left"><strong>  {{$errors->first('SWEusername')}}</strong></p>--}}
                            {{--@endif--}}
                        </div>
                    </div>
                    <div class="middle">
                        <div class="middle-padding">
                            <!--管理员权限很大 可以直接对所有用户进行操作-->
                            <input class="form-control" type="text" style="width: 60%;height: 10%" placeholder="作者ID" id="userid" name="userid">
                        </div>
                    </div>

                    <div class="middle">
                        <div class="middle-padding">
                            <!-- 加载编辑器的容器 --><!--在外部js中实例化编辑器 -->
                            <script id="container" name="content" type="text/plain" style='width:100%;height:300px;'></script>
                            </div>
                    </div>

                            <div class="middle">
                                <div class="middle-padding">
                                <input class="form-control" type="text" style="width: 60%;height: 10%" placeholder="标签" id="tage" name="tage">
                                </div>
                                </div>

                                <div class="middle">
                                <div class="middle-padding">
                                <input class="form-control" type="file" style="width: 60%;height: 10%" placeholder="图片" id="pic" name="pic">
                                </div>
                                </div>
                                <div class="middle">
                                <div class="middle-padding">
                                <input class="form-control" type="file" style="width: 60%;height: 10%" placeholder="视频" id="video" name="video">
                                </div>
                                </div>

                    <div class="middle">
                        <div class="middle-padding">
                         <input id ="submit" class="btn btn-default" style="width: 20%;height: 10%;font-size:6px"
                            type="submit" value="提交">
                        </div>
                     <div>
                </form>
        </div>
   </div>
    </body>
</html>
