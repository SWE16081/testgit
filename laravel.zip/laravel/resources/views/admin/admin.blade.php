<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!--引入后端css样式-->
        <link href="../../../css/admin/indexuser/indexuser.css" rel="stylesheet">
        <!--引入后端js-->
        {{--<script src="../../../js/admin/admin.js"></script>--}}

        <title>用户</title>
    </head>
    <body>

    <div class="container">
    @include('common.top')
        <ol class="title breadcrumb" >
            <a href="{{url('/adminadd')}}" >添加用户</a>-------
            <li ><a href="#">用户</a></li>
            <li ><a href="#">显示</a></li>

        </ol>
        <div class="divtable">
            <table  class="table table-hover" >
                <tr class="adtable">
                    <td class="active" >账号</td>
                    <td class="active" >密码</td>
                    <td class="active" >操作</td>
                    <td class="active">操作</td>

                </tr>
                @foreach($user as $users)
                    <tr class="adtable">
                        <td class="success" >{{$users->username}}</td>
                        <td class="success" >{{$users->password}}</td>
                        <td class="warning">
                            <a href="{{url('/adminupdate',['userid'=>$users->userid])}}"><button class="btn btn-default">修改</button></a>
                        </td>
                        <td class="warning">
                            <a href="{{url('/admindelete',['userid'=>$users->userid])}}"><button class="btn btn-default">删除</button></a>
                        </td>

                    </tr>
                @endforeach


            </table>
        </div>

        <div class="paging">
            <hr />
            <span class="pageSpan">{{$user->links()}}</span>
        </div>
    </div>

    </body>
</html>
