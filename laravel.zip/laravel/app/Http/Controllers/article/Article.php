<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/2
 * Time: 13:52
 */
namespace  App\Http\Controllers\article;

use App\Http\Controllers\Controller;
use App\Http\Validate\ArticleAdd;
use Illuminate\Http\Request;
use App\Http\Models\article as articleModel;
use Illuminate\Support\Facades\Input;


class Article extends Controller {

    //文件测试
    public function articleShowtest(Request $request){
        if($request->isMethod('post')){
            //获取上传文件
            $file=$request->file('file');
            if($file->isValid())             //检测上传的文件是否合法，返回值为true或false
            {
                // 获取上传文件名
                $filename=$file->getClientOriginalName();
                //获取文件后缀名
                $fileextension=$file->getClientOriginalExtension();
                //获取文件大小
                $filesize=$file->getClientSize();
                //获取缓存在tmp目录下的文件名
                $filename2=$file->getFilename();
                //获取上传的文件缓存在tmp文件夹下的绝对路径
                $realpath=$file->getRealPath();

                //将缓存在tmp目录下的文件移到某个位置，返回的是这个文件移动过后的路径
                $path=$file->move( './uploads/fails/',$filename);
            }
        }

        return view('article.article');
    }
    //文章查询显示
    public function articleShow(){
        $article=new articleModel();
        $res=$article->selArticle();
        foreach ($res as $s){
            $subject= strip_tags($s->content);//strip_tags() 函数剥去字符串中的 HTML、XML 以及 PHP 的标签。
            //但&nbsp;有去除 ，而且ueditor后面会多一个空格
            $pattern = '&nbsp;';//去除空白
            $s->content= str_replace($pattern, '', $subject);
            $s->content= str_replace(' ', '', $s->content);
        }


        return view('article.article',['article'=>$res]);
    }
    //文章添加
    public function articleAdd(Request $request){
        if($request->isMethod('post')){
            //获取数据
            $data=Input::all();

            //数据检验
            $check=new ArticleAdd();
            $res=$check->check($data);

            if($res){

                $swe=new articleModel();
                $res2=$swe->addArticle($data);//插入数据
                if($res2){
                    return redirect('/articleshow');
                }else{
//                    return redirect('/adminadd');
                    return view('admin/adminadd');
                }
            }

            //返回
        }else{
//            return view('article/articleadd');
            return view('article.articleadd');//等价
        }

    }
    //文章内容查看
    public function contentShow($data){
        $article=new articleModel();
        $res=$article->contentShow($data);
        return view('article.articlecontent',['article'=>$res]);
    }
    //文章内容修改
    public function articleUpdate(Request $request,$id){

        $check=new articleModel();
        $result=$check->articleUpdateSel($id);
        if($request->isMethod('post')){
            $data=Input::all();
            //数据检验
            $check=new ArticleAdd();
            $res=$check->check($data);

            if($res){
                $swe=new articleModel();
                $res2=$swe->articleUpdate($id,$data);//插入数据
                if($res2){
                    return redirect()->route('articlecontent', ['id'=>$id]);
//                    return redirect('articleshow');
                }
                else{

                    return view ('article/articleupdate',['article'=>$result]);
                }
            }
        }else{
            return view ('article/articleupdate',['article'=>$result]);
        }

    }

}