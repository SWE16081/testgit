<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/4/1
 * Time: 20:36
 */

namespace App\Http\Validate;


use Illuminate\Support\Facades\Validator;
class ArticleAdd
{
    public function check(array $data)
    {
        $res=Validator::make($data,[
            'userid'=>'required',
            'content'=>'required',
            'title'=>'required',
            'tage'=>'required',
        ],
            [
                'userid.required'=>'指定的用户id不能为空',
                 'content.required'=>'内容不能为空',
                 'title.required'=>'标题不能为空',
                 'tage.required'=>'标签不能为空',
            ]
        )->validate();
        return $res;

    }

}