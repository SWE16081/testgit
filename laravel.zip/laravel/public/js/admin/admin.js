/**
 * Created by SWESWE on 2019/3/3.
 */
window.onload=function(){
    var change=document.getElementById('change');
    change.onclick=function () {
    window.open('/adminupdate');
    }
}