<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <!--移动设备友好样式-->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!--引入后端css样式-->
        <link href="../../../css/admin/login/adminlogin.css" rel="stylesheet">
        <title>SWE16081login--div</title>


    <body>
         <div class="content">
             <div class="pic-img">
                 <img src="../../../pic/hou.png">
             </div>
             <form method="post" action="/login">
                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" /><!--419bug-->

                 <div class="middle">
                     <div class="middle-padding">
                         <input class="form-control" type="text" value="<?php echo e(old('SWEusername')); ?>" placeholder="账号" id="SWEusername" name="SWEusername">
                             <?php if($errors->has('SWEusername')): ?>
                             <p class="text-danger text-left"><strong>  <?php echo e($errors->first('SWEusername')); ?></strong></p>
                            <?php endif; ?>
                     </div>

                     <div class="middle-padding">
                         <input  class="form-control" type="password" value="<?php echo e(old('SWEpassword')); ?>" placeholder="密码" id="SWEpassword" name="SWEpassword">
                         <?php if($errors->has('SWEpassword')): ?>
                             <script>alert('<?php echo e($errors->first('SWEpassword')); ?>')</script>

                         <?php endif; ?>
                         <?php if(session('error')): ?>
                             <script>alert('<?php echo e(session('error')); ?>')</script>

                         <?php endif; ?>
                     </div>
                     <div class="middle-padding">
                         <img class="code"src="<?php echo e(captcha_src('flat')); ?>" style="cursor: pointer;width: 200px;height:34px;" onclick="this.src='<?php echo e(captcha_src('flat')); ?>'+Math.random()">
                     </div>
                     <div class="middle-padding">
                         <input type="text" class="form-control "value="<?php echo e(old('SWEcode')); ?>" id="SWEcode" name="SWEcode" placeholder="captcha">
                         <?php if($errors->has('SWEcode')): ?>
                                 <p class="text-danger text-left"><strong><?php echo e($errors->first('SWEcode')); ?></strong></p>
                         <?php endif; ?>
                     </div>

                     <div class="middle-padding">
                         <input class="btn btn-default"type="submit" value="登陆">
                     </div>

                 </div>
             </form>


         </div>
    </body>
</html>
