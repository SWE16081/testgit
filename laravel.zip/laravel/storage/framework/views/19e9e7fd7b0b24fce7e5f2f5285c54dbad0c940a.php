<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <title>文章</title>
    </head>
    <body>

    <div class="container">
    <?php echo $__env->make('common.top', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/articleadd')); ?>">文章添加</a></li>
            <li><a href="#">文章</a></li>
            <li><a href="#">显示</a></li>
        </ol>
      <div>
           <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="list-group">
                  <a href="<?php echo e(url('/articlecontent',['articleid'=>$articles->articleid])); ?>" class="list-group-item default">
                  
                      <?php echo e(str_limit($articles->content, 120,'...')); ?>


                  </a>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <div class="paging">
                   <hr />
                   <span class="pageSpan"><?php echo e($article->links()); ?></span>
               </div>

      </div>
    </div>

    </div>
    </body>
</html>
