<?php

namespace App\Http\Controllers\home;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;


class Home extends Controller
{
   public function homeshow(Request $request)
   {

                  return view('index.index');




   }


}
