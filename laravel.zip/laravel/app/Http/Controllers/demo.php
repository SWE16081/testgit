<?php

namespace App\Http\Controllers;
use App\Http\Models\blog;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\controller;
class demo extends controller
{
    public  function show()
    {
        return  view('demo.file',['name'=>'软工SWE16081']);
    }

    public function lit($id,$name)
    {
        return $id.'eqw'.$name;
    }

    public function display()
    {
        $users = DB::select('select * from la_blogs');
        return view('demo.file',['users'=>$users]);
//        return $users;
//        dump($users);
    }

    public function select()
    {
//        $user=DB::table('blogs')->get();//获取表中所有与记录
//        $user=DB::table('blogs')->where('id','1')->first();//使用first方法获取表中一行数据
//        $user=DB::table('blogs')->where('id','1')->value('title');//获取一行中，某个单值
        //获取包含单个列值的数组，可以使用 pluck 方法
//        $user=DB::table('blogs')->pluck('content');//获取一个列的值
        //在返回数组中为列值指定自定义键（该自定义键必须是该表的其它字段列名
        $user=DB::table('blogs')->pluck('content','title');
        dump($user);
    }

    public function input(Request $request)//依赖注入
    {
       $name=$request->input('name');
        $password=$request->input('password');
        if($name!=null&&$password!=null)
        {
            return view('demo.file',['name'=>$name]);
        }
        else{
            dump($name);
            dump($password);
            return view('demo.file');
        }
    }

    public function eloquent()
    {
//          $modelBlog=new ModelBlog();
//          dump($modelBlog->select());
        $data=blog::all();
        $data2=blog::find(1);
        $data2->content='艾弗森132';
        $data2->save();
        dump($data);
        dump($data2);
    }

}
