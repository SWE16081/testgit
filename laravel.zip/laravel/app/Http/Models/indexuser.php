<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/2
 * Time: 14:18
 */
namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class indexuser extends  Model{
    public $timestamps = false;
    protected  $table='indexuser';

    //添加用户
    public function useradd($data){
        $indexuser=new indexuser();
        $indexuser->username=$data['SWEusername'];
        $indexuser->password=$data['SWEpassword'];
        $res=$indexuser->save();
        return $res;
    }

    //查询用户信息
    public function userselect(){
      $res=indexuser::Paginate(4);
//        $res=DB::table('indexuser')->paginate(4);
      return $res;
    }
    //修改用户信息
    public function userupdate($id,$data){
//        dump($data);
        $indexuser=new indexuser();
        $res=$indexuser::where('userid',$id)->update(['password'=>$data['SWEpassword']]);
        return $res;
    }

    //修改信息时查询修改前的账号密码
    public function updatesel($id){
        $res=indexuser::where('userid',$id)->first();
//        dump($res);
        return $res;
    }

    //删除账号
    public function updatedelete($id){
        $res=indexuser::where('userid',$id)->delete();

        return $res;
    }
}
