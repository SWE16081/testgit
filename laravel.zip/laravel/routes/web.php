<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware'=>['web']],function(){

});
Route::get('/', function () {

    session(['key'=>123]);//设置session
//    return view('index');
    return view('welcome');
});
Route::get('/swe',function(){
   echo session('key');//读取session
   return 'swe';
});

Route::get('/login2','Login@login');

//$data=['name'=>'SWE16081'];
Route::get('/demo',function() {
    return view('demo',['name'=>'SWE16081','title'=>'软件','records'=>'0']);
});



Route::get('/demo/show','Demo@show');

//命名路由
Route::any('/demo2',function() {
    // 通过路由名称生成 URL
    return '修改了laravel项目my url: ' . route('pre');

})->name('pre');
Route::get('redirect',function(){
   //通过路由名进行重定向
    return redirect()->route('pre');
});

Route::get('/demo/lit/{id}/{name}','Demo@lit');
//Route::get('/demo/display','Demo@display');
//Route::get('/demo/select','Demo@select');
//Route::any('/demo/input','Demo@input');
//路由分组
Route::group(['prefix'=>'/demo'],function(){
    Route::get('/display','Demo@display');
    Route::get('/select','Demo@select');
    Route::any('/input','Demo@input');
});
Route::get('/demo/eloquent','Demo@eloquent');

//后端管理员登陆
Route::any('/login','login\login@login');//多级控制器跳转
Route::any('/login2','login\login@login2');//多级控制器跳转
Route::group(['middleware'=>['token']],function(){
    Route::get('/home','home\home@homeshow');
});
Route::any('/loginindex','login@login');//多级控制器跳转
//Route::any('/home',function(){
////    return redirect('/login');
////    return view('index.index');
//})->middleware('token');
//Route::any('/login', function () {
//    //
//})->middleware('token');
//Route::any('/home','home\home@homeshow');
Route::post('/test',function (){
//    echo csrf_token();
    echo"post";
});
Route::get('/test2',function (){
    echo"get";
});
Route::put('/put',function (){
    echo"put";
});
Route::delete('/delete',function (){
    echo"delete";
});
Route::patch('/patch',function (){
    echo"patch";
});
Route::options('/options',function (){
    echo"options";
});

//用户 文章  标签
Route::any('/adminshow','admin\admin@adminShow');
Route::any('/adminadd','admin\admin@adminAdd');
Route::any('/adminupdate/{id}','admin\admin@adminUpdate');
Route::any('/admindelete/{id}','admin\admin@adminDelete');
Route::any('/articleshow','article\article@articleShow');
Route::any('/articleadd','article\article@articleAdd');
Route::any('/articlecontent/{id}','article\article@contentShow')->name('articlecontent');
Route::any('/articleupdate/{id}','article\article@articleUpdate');
Route::get('/tagsshow','tags\tags@tagsShow');

//获取图片接口
Route::post('/getPicCode','api\picfile@getPicCode');
Route::post('/insertCode','api\picfile@insertCode');
Route::post('/inputfile','api\picfile@inputfile');