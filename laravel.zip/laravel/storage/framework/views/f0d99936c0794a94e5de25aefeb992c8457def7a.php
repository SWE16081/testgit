<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!--引入后端css样式-->
        <link href="../../../css/admin/indexuser/indexuser.css" rel="stylesheet">
        <!--引入后端js-->
        

        <title>用户</title>
    </head>
    <body>

    <div class="container">
    <?php echo $__env->make('common.top', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <ol class="title breadcrumb" >
            <a href="<?php echo e(url('/adminadd')); ?>" >添加用户</a>-------
            <li ><a href="#">用户</a></li>
            <li ><a href="#">显示</a></li>

        </ol>
        <div class="divtable">
            <table  class="table table-hover" >
                <tr class="adtable">
                    <td class="active" >账号</td>
                    <td class="active" >密码</td>
                    <td class="active" >操作</td>
                    <td class="active">操作</td>

                </tr>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="adtable">
                        <td class="success" ><?php echo e($users->username); ?></td>
                        <td class="success" ><?php echo e($users->password); ?></td>
                        <td class="warning">
                            <a href="<?php echo e(url('/adminupdate',['userid'=>$users->userid])); ?>"><button class="btn btn-default">修改</button></a>
                        </td>
                        <td class="warning">
                            <a href="<?php echo e(url('/admindelete',['userid'=>$users->userid])); ?>"><button class="btn btn-default">删除</button></a>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>
        </div>

        <div class="paging">
            <hr />
            <span class="pageSpan"><?php echo e($user->links()); ?></span>
        </div>
    </div>

    </body>
</html>
