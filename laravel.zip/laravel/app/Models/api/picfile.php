<?php

namespace App\Models\api;

use Illuminate\Database\Eloquent\Model;

class picfile extends Model
{
    //
    protected  $table="picfile";
    public $timestamps=false;

    //伪查询 测试
    public function select($id){
        $res=picfile::where('id',$id)->first();
        return $res;
    }


    //伪插入 测试
    public function  insert($data){
        $picfile=new picfile();
        $picfile->piccode=$data['piccode'];
        $picfile->kind=$data['kind'];
        $picfile->username=$data['username'];
        $res=$picfile->save();
        return $res;
    }

}
