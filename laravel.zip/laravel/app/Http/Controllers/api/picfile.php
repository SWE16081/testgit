<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\controller;
use App\Models\api\picfile as modelpic;
use Illuminate\Support\Facades\Input;

class picfile extends controller
{
    //
    public function getPicCode()
    {

            $picfile=new modelpic();
            $res=$picfile->select(4);
            return  $res;

    }
    public function insertCode(Request $request)
    {
        if($request->isMethod('post')){
            $data=Input::all();
//            $piccode=$request->input('piccode');
//            $kind=$request->input('kind');
            $picfile=new modelpic();
            $res=$picfile->insert($data);
            if($res){
                return \GuzzleHttp\json_encode(['res'=>'true']);
            }else{
                return \GuzzleHttp\json_encode(['error'=>'404']);
            }

        }
    }

    public function inputfile(Request $request)
    {
        if ($request->isMethod('post')){
            $data=Input::all();
            $picfile=new modelpic();
            $res=$picfile->insert($data);
            if($res){
                return \GuzzleHttp\json_encode(['res'=>'true']);
            }else{
                return \GuzzleHttp\json_encode(['error'=>'404']);
            }
        }
    }



}
