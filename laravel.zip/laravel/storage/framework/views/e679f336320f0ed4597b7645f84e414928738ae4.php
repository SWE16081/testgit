<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <body>

       <div><?php echo e($name); ?>第一次修改啦laravel项目<?php echo e($title); ?></div>
       <?php if($records === 1): ?>
           I have one record!
       <?php elseif($records > 1): ?>
           I have multiple records!
       <?php else: ?>
           I don't have any records!
       <?php endif; ?>

       <?php for($i=0;$i<10;$i++): ?>
         目前的数值为<?php echo e($i); ?>

       <?php endfor; ?>
    </body>
</html>
