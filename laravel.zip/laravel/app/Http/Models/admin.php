<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/2/25
 * Time: 10:45
 */
namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
class admin extends Model
{
    public $timestamps = false;//Eloquent 期望 created_at 和 updated_at 已经存在于数据表中 即数据表中存在这两个字段
    //    // 模型该使用哪一个数据表。除非数据表明确地指定了其它名称，否则将使用类的复数形式「蛇形命名」来作为表名
    protected $table = 'sweadmin';
    //查询


}
