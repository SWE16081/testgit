<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <title>Laravel</title>
    </head>
    <body>

       {{--<div>{{$name}}啦啦啦</div>--}}
       {{--@foreach ($users as $user)--}}
           {{--{{$user->id}}--}}
      {{--{{$user->content}}<br>--}}
       {{--@endforeach--}}
       {{ isset($name) ? $name : 'Default' }}
       <form method="POST" action="/demo2">
           <input type="hidden" name="_token" value="{{ csrf_token() }}" />
           <div class="form-group">
               <label for="exampleInputEmail1">Email address</label>
               <input type="text" class="form-control" name="name" id="name" placeholder="name">
           </div>
           <div class="form-group">
               <label for="exampleInputPassword1">Password</label>
               <input type="password" class="form-control" name="password" id="password" placeholder="Password">
           </div>
           <button type="submit" class="btn btn-default">Submit</button>
       </form>
    </body>
</html>
