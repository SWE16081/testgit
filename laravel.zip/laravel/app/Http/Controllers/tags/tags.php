<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/2
 * Time: 13:54
 */
namespace  App\Http\Controllers\tags;

use App\Http\Controllers\controller;

class tags extends controller{
    public function tagsShow(){
        return view('tags.tag');
    }
}