<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/3
 * Time: 11:25
 */
namespace  App\Http\Validate;

use App\Rules\SensitiveWordRule;
use Illuminate\Support\Facades\Validator;

class AdminAddValidate {
    public function check(array $data){
        $res=Validator::make($data,[
            'SWEusername'=>[    'required',//'between:6,10',//'alpha_dash', //alpha_dash 验证字段可以包含字母和数字，以及破折号和下划线。
                function($attibute,$value,$fail)
                {
                    if(strpos($value,'国家')!==false)
                    {
                        return $fail('内容包含敏感词');
                    }
               },
                new SensitiveWordRule(),
                'regex:/^[0-9a-zA-Z@_]{6,10}$/',
                'unique:indexuser,username'
            ],
            'SWEpassword'=>['required','regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[@_])(?=.*[a-z]).{7,16}$/'],
            ],
            [
                'SWEusername.required'=>'账号不能为空',
                'SWEusername.unique'=>'此账号已存在',
                'SWEusername.regex'=>'账号格式错误',
                'SWEpassword.required'=>'密码不能为空',
                'SWEpassword.regex'=>'密码格式错误',
            ]
        )->validate();
        return $res;
    }

}