<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/5
 * Time: 10:14
 */
namespace  App\Http\Validate;

use Illuminate\Support\Facades\Validator;

class AdminUpdateValidate
{
    public function check(array $data){
        $res=Validator::make($data,
            [
                 'SWEpassword'=>[
                     'required',
                     'regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[a-z]).{7,16}$/',
                 ],
                  'SWEpassword2'=>[  'same:SWEpassword'
                  ]
            ],
            [
                'SWEpassword.required'=>'密码不能为空',
                'SWEpassword.regex'=>'密码为7-16位包含到小写数字的字符',
                'SWEpassword2.same'=>'两次密码不一致',
            ]
        )->validate();
        return $res;
    }
}
