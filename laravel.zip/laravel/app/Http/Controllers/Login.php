<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Models\admin;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\DB;


class Login extends Controller
{
   public function login(Request $request)
   {
       if($request->isMethod('post'))//判断请求是否为post请求
       {
           $username=$request->input('username');
           $password=$request->input('password');
          if($username=="SWE16081"&&$password="123456"){
              return \GuzzleHttp\json_encode(['res'=>'true']);
          }
          else{
              return \GuzzleHttp\json_encode(['res'=>'false']);
          }

       }
       return '123';
   }



}
