<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/2/25
 * Time: 10:45
 */
namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
class article extends Model
{
    public $timestamps = false;//Eloquent 期望 created_at 和 updated_at 已经存在于数据表中 即数据表中存在这两个字段
    //    // 模型该使用哪一个数据表。除非数据表明确地指定了其它名称，否则将使用类的复数形式「蛇形命名」来作为表名
    protected $table = 'article';

    //文章查询
    public function  selArticle()
    {
        $res=article::Paginate(4);
        return $res;
    }

    //文章添加
    public function addArticle($data)
  {
      $article=new article();
       $article->userid=$data['userid'];
       $article->content=$data['content'];
      $article->title=$data['title'];
      $article->tag=$data['tage'];
//      $article->pic=$data['video'];
      $res=$article->save();
      return $res;
  }

    //文章内容查看
    public function contentShow($data){
        $article=new article();
        $res=$article::where('articleid',$data)->first();
        return $res;
    }
    //文章修改
    public function articleUpdate($id,$data){
        $article=new article();
        $res=$article::where('articleid',$id)->update(['title'=>$data['title'],'userid'=>$data['userid'],
            'content'=>$data['content'],
            'tag'=>$data['tage']
        ]);
        return $res;
    }
    //文章修改查询
    public function articleUpdateSel($id){
        $res=article::where('articleid',$id)->first();
        return $res;

    }
}
