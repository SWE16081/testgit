<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/2
 * Time: 13:34
 */
namespace App\Http\Controllers\admin;



use App\Http\Controllers\controller;
use App\Http\Models\indexuser;
use App\Http\Validate\AdminAddValidate;
use App\Http\Validate\AdminUpdateValidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class admin extends controller {
   //用户查询
    public function adminShow(){
        $swe=new indexuser();
        $data=$swe->userselect();
//        dump($data);
        return view('admin.admin',['user'=>$data]);
    }
    //用户添加
    public function adminAdd(Request $request){

        if($request->isMethod('post')){
            $data=Input::all();//获取提交数据
            $res=new AdminAddValidate();
            $res2=$res->check($data);//验证数据
            if($res2){
                $swe=new indexuser();
                $res3=$swe->useradd($data);//插入数据
                if($res3){
                    return redirect('/adminshow');
                }else{
//                    return redirect('/adminadd');
                    return view('admin/adminadd');
                }
            }
        }
        else
            return view('admin/adminadd');
    }
    //用户修改
    public function adminUpdate(Request $request,$id){

        if($request->isMethod('post')){

            $data=Input::all();
//            dump($data);exit();
            $res=new AdminUpdateValidate();
            $res2=$res->check($data);
            if($res2){

                $indexuser=new indexuser();
                $res3=$indexuser->userupdate($id,$data);
                if($res3)
                {

                    return redirect('/adminshow');
                }
                else{

                    $swe=new indexuser();
                    $data=$swe->updatesel($id);
                    return view('admin.adminupdate',['user'=>$data]);
                }
            }
        }
        else{

            $swe=new indexuser();
            $data=$swe->updatesel($id);
//            dump($id);exit();
            return view('admin.adminupdate',['user'=>$data]);
        }


    }
    //用户删除
    public function adminDelete($id){
     $indexuser=new indexuser();
     $res=$indexuser->updatedelete($id);
     if($res){
         return redirect('/adminshow');
     }

    }
}