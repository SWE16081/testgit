<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- 新 Bootstrap 核心 CSS 文件 -->
        <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
        <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>

        <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
        <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <title>文章</title>
    </head>
    <body>

    <div class="container">
    @include('common.top')
    <div>
        <ol class="breadcrumb">
            <li><a href="{{url('/articleshow')}}">后退</a></li>
            <li><a href="#">文章内容</a></li>
            <li><a href="{{url('/articleupdate',['articleid'=>$article->articleid])}}">编辑</a></li>
        </ol>
      <div>

              <div class="list-group">
                  <div class="list-group-item default" >
                  <h4 class="list-group-item-heading" style="text-align: center">{{$article->title}}</h4>
                      <hr/>
                  <p class="list-group-item-text">  {!! $article->content !!}</p>
                  </div>
              </div>



      </div>
    </div>

    </div>
    </body>
</html>
