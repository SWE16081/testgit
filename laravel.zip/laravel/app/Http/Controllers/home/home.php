<?php

namespace App\Http\Controllers\home;
use Illuminate\Http\Request;
use App\Http\Controllers\controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;


class home extends controller
{
   public function homeshow(Request $request)
   {

                  return view('index.index');




   }


}
