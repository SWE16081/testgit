/**
 * Created by SWESWE on 2019/4/1.
 */
window.onload=function(){
    var ue = UE.getEditor('container');
    ue.ready(function() {
        //设置编辑器的内容
        // ue.setContent({!! $article->content!!});
    //
    });
    // ue.ready(function(){
    //     //添加laravel安全token：
    //     ue.execCommand('serverparam', '_token', '{{ csrf_token() }}');
    // });
    // var editor=document.getElementById('editor')
    // ue.onblur=function () {
    //     var s = ue.getContent();
    //     editor.value=s;
    //     console.log(editor.value)
    // }
}