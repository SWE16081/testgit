<?php

namespace App\Http\Controllers\login;
use App\Http\Requests\StoreBlogPost;
use Illuminate\Http\Request;
use App\Http\Controllers\controller;
use App\Http\Validate\LoginValidate ;
use App\Http\Models\admin;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;


class login extends controller
{
//    public function login(Request $request)
   public function login(Request $request)
   {
//       $request->isMethod('post')//判断请求是否为post请求
//       Input::all();//laravel获取表单提交的全部数据
       if($request->isMethod('post'))
       {
           $res =new LoginValidate;
           $res2=$res->check(Input::all());
           if($res2)//验证码正确
           {
               //获取输入的账号密码
               $username=$request->input('SWEusername');
               $password=$request->input('SWEpassword');
               //验证
               $adusername=admin::where('sweusername',$username)->first(['swepassword']);
               if($adusername){
                   if($password==$adusername['swepassword'])
                   {
                       session(['admin'=>$username]);//存储登录信息
                       return redirect('/home');

                   }
                   else{
                       return redirect('/login')->with('error','账号密码错误');
                   }
               }
               else{
                   return redirect('/login')->with('error','账号密码错误');
               }
           }
//           $res->check(Input::all());
//           dump($res->check(Input::all()));
       }
       return view('login.login');
   }
        public function login2(StoreBlogPost $request){

            return redirect('/home');
        }


}
