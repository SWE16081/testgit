<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreBlogPost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;//用于检查用户权限，如果返回 false 则表示用户无权提交表单，会抛出权限异常中止请求
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //获取应用到请求的验证规则
        return [
            //
            'SWEusername'=> 'required',
            'SWEpassword' => 'required',
            'SWEcode' => 'required|captcha',

        ];
    }
//重写父类的 messages() 方法 错误提示信息
    public function messages()
    {
        return [
            'SWEusername.required'=>trans('账号不能为空'),
            'SWEpassword.required'=>trans('密码不能为空'),
            'SWEcode.required' => trans('验证码不能为空'),
            'SWEcode.captcha' => trans('验证码错误'),
        ];
    }
}
