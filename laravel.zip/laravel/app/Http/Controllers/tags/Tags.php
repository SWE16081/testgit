<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/3/2
 * Time: 13:54
 */
namespace  App\Http\Controllers\tags;

use App\Http\Controllers\Controller;

class Tags extends Controller{
    public function tagsShow(){
        return view('tags.tag');
    }
}