<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <body>

       <div>{{$name}}第一次修改啦laravel项目{{$title}}</div>
       @if ($records === 1)
           I have one record!
       @elseif ($records > 1)
           I have multiple records!
       @else
           I don't have any records!
       @endif

       @for($i=0;$i<10;$i++)
         目前的数值为{{$i}}
       @endfor
    </body>
</html>
